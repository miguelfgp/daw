/* 
fichero con codigo javascript
alumno:
fecha:
*/

var nombre = prompt("Introduce tu nombre");
var edad = prompt("Introduce tu edad");
var mensaje = "Tu nombre es " +nombre+ " y tienes "+edad+" años"

document.getElementById("ubicacion1").innerHTML = mensaje;
