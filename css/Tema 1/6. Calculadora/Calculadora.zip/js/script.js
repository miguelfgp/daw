var result = 0;
var op;
var sign;
var operating = false;

function insertNumber(num){
    var screenNumber = document.getElementById('screen').innerHTML;

    if (screenNumber.length < 5){
        if (screenNumber.localeCompare("0") && !operating){
            document.getElementById('screen').innerHTML += num;
        } else {
            document.getElementById('screen').innerHTML = num;
            operating = false;
        }
    }
}

function deleteScreen(){
    document.getElementById('screen').innerHTML = '0';
    result = 0;
}

function operate(key){
    operating = true;
    sign = key;

    switch (sign){
        case '+': sum(); break;
        case '-': sub(); break;
        case 'X': mult(); break;
        case '/': div(); break;
        case '=': results(); break;
    }
}

function sum(){
    document.getElementById('screen').innerHTML = result + parseInt(document.getElementById('screen').innerHTML);
    result = parseInt(document.getElementById('screen').innerHTML);
}

function sub(){
    if (result != 0){
        document.getElementById('screen').innerHTML = result - parseInt(document.getElementById('screen').innerHTML);
    }
    result = parseInt(document.getElementById('screen').innerHTML);
}

function mult(){
    if (result != 0){
        document.getElementById('screen').innerHTML = result * parseInt(document.getElementById('screen').innerHTML);
    }

    result = parseInt(document.getElementById('screen').innerHTML);
}

function div(){
    if (result != 0){
        document.getElementById('screen').innerHTML = result / parseInt(document.getElementById('screen').innerHTML);
    }

    result = parseInt(document.getElementById('screen').innerHTML);
}

function results(){
    op = parseInt(document.getElementById('screen').innerHTML);
    
    switch(sign){
        case '+': result += op; break;
        case '-': result -= op; break;
        case 'X': result *= op; break;
        case '/': result /= op; break;
    }

    document.getElementById('screen').innerHTML = result;
    result = 0;
    op = 0;
    operating = false;
}