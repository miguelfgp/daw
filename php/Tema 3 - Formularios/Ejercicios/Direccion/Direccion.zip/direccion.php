<?php

    $direccion = "";
    
    if(isset($_POST) && !empty($_POST)){
        if(ctype_digit($_POST['numero'])){
            $direccion .= $_POST['tipo'] . ' ' . $_POST['nombre'] . ' ' . $_POST['numero'] . '<br>' . $_POST['poblacion'] . ' ' . $_POST['pais'];
        }
    }
 

    if (!empty($direccion)){
        echo $direccion;
    } else {
        echo "Introduzca una dirección correcta";
    }

?>