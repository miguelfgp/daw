<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="css/style.css">
    <meta charset="utf-8">
</head>
<body>
    <div id="main">
        <h1>Práctica examen -  Miguel FGP</h1>

        <h3>Elige una opción</h3>

        <nav>
            <ul>
                <li><a href="createEmpleado.php">Crear Empleado</a></li>
                <li><a href="updateEmpleado.php">Actualizar Empleado</a></li>
                <li><a href="deleteEmpleado.php">Eliminar Empleado</a></li>
            </ul>
        </nav>
    </div>
</body>
</html>
