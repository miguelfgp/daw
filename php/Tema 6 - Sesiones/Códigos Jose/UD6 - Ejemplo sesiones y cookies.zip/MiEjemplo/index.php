<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>DWES</title>
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
  <link rel="stylesheet" href="estilo.css">
</head>
<body>
  <h2>DESARROLLO WEB ENTORNO SERVIDOR - Ejemplo sesiones + cookies - Unidad 6</h2>
  <fieldset>
  	<br>
	<form action="inicio.php" method="post">
		<label>Usuario:</label>
		<input type="text" name="usuario" required><br><br>
		<input type="submit" class="w3-button w3-black" name="enviar" value="Enviar">
	</form>
	</fieldset>
  <footer>
    <h6>Asignatura: Desarrollo Web en Entorno Servidor</h6>
  </footer>
</body>
</html>