<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>DWES</title>
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
  <link rel="stylesheet" href="estilo.css">
</head>
<body>
  <h2>DESARROLLO WEB ENTORNO SERVIDOR - Caso Práctico 1 - Unidad 6 - Carrito de compra</h2>
  <a href="procesar_carrito.php"><b>Ver Carrito</b></a></br></br>
  <fieldset>
    <legend>Seleccione un producto</legend>
      <a href="producto1.php">Producto 1</a></br></br>
      <a href="producto2.php">Producto 2</a></br></br>
      <a href="producto3.php">Producto 3</a></br></br>
      <a href="producto4.php">Producto 4</a></br></br>
      </br>
  </fieldset></br>
  <footer>
    <h6>Asignatura: Desarrollo Web Entorno Servidor</h6>
  </footer>
  </body>
</html>
